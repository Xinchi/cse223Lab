package triblab

import (
	"trib"
)

func NewFront(backs []string) trib.Server {
	panic("todo")
}
